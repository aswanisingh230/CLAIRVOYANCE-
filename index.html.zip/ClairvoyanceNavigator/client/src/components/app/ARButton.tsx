import { Button } from "@/components/ui/button";
import { Camera } from "lucide-react";

interface ARButtonProps {
  onActivate?: () => void;
}

export default function ARButton({ onActivate }: ARButtonProps) {
  return (
    <Button
      size="lg"
      className="rounded-full w-14 h-14 shadow-lg"
      onClick={() => {
        onActivate?.();
        console.log('AR mode activated');
      }}
      data-testid="button-ar-activate"
    >
      <Camera className="h-6 w-6" />
    </Button>
  );
}
