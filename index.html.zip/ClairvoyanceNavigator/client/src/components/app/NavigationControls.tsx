import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Plus, Minus, RotateCw } from "lucide-react";

interface NavigationControlsProps {
  currentFloor?: number;
  totalFloors?: number;
  onFloorChange?: (floor: number) => void;
  onZoomIn?: () => void;
  onZoomOut?: () => void;
  onReset?: () => void;
}

export default function NavigationControls({
  currentFloor = 1,
  totalFloors = 3,
  onFloorChange,
  onZoomIn,
  onZoomOut,
  onReset
}: NavigationControlsProps) {
  return (
    <Card className="p-4 bg-background/95 backdrop-blur-sm" data-testid="navigation-controls">
      <div className="space-y-4">
        <div>
          <div className="text-xs font-medium text-muted-foreground mb-2">Floor</div>
          <div className="flex flex-col gap-1">
            {Array.from({ length: totalFloors }, (_, i) => totalFloors - i).map((floor) => (
              <Button
                key={floor}
                variant={floor === currentFloor ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  onFloorChange?.(floor);
                  console.log('Floor changed to:', floor);
                }}
                data-testid={`button-floor-${floor}`}
                className="w-full"
              >
                {floor}
              </Button>
            ))}
          </div>
        </div>
        
        <div className="border-t pt-4">
          <div className="text-xs font-medium text-muted-foreground mb-2">Zoom</div>
          <div className="flex flex-col gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                onZoomIn?.();
                console.log('Zoom in');
              }}
              data-testid="button-zoom-in"
            >
              <Plus className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                onZoomOut?.();
                console.log('Zoom out');
              }}
              data-testid="button-zoom-out"
            >
              <Minus className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="border-t pt-4">
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={() => {
              onReset?.();
              console.log('Reset view');
            }}
            data-testid="button-reset"
          >
            <RotateCw className="h-4 w-4 mr-2" />
            Reset
          </Button>
        </div>
      </div>
    </Card>
  );
}
