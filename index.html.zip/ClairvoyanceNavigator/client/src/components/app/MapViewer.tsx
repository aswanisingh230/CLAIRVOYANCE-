import { useState } from "react";
import { Card } from "@/components/ui/card";
import floorPlanImage from "@assets/generated_images/3D_floor_plan_visualization_a301eff3.png";

interface POIMarker {
  id: string;
  x: number;
  y: number;
  type: string;
  label: string;
}

interface MapViewerProps {
  activePath?: { x: number; y: number }[];
  markers?: POIMarker[];
}

export default function MapViewer({ activePath = [], markers = [] }: MapViewerProps) {
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });

  return (
    <div className="relative w-full h-full bg-muted/20 overflow-hidden" data-testid="map-viewer">
      <div 
        className="absolute inset-0 transition-transform duration-300"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
        }}
      >
        <img 
          src={floorPlanImage} 
          alt="3D Floor Plan"
          className="w-full h-full object-contain"
        />
        
        {activePath.length > 0 && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            <path
              d={`M ${activePath.map(p => `${p.x},${p.y}`).join(' L ')}`}
              stroke="hsl(var(--primary))"
              strokeWidth="4"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="drop-shadow-lg"
            />
          </svg>
        )}
        
        {markers.map((marker) => (
          <div
            key={marker.id}
            className="absolute w-8 h-8 -ml-4 -mt-4 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-xs font-bold shadow-lg cursor-pointer hover-elevate"
            style={{ left: `${marker.x}%`, top: `${marker.y}%` }}
            data-testid={`marker-${marker.id}`}
            onClick={() => console.log('Marker clicked:', marker.label)}
          >
            {marker.type === 'start' ? 'A' : marker.type === 'end' ? 'B' : '•'}
          </div>
        ))}
      </div>
    </div>
  );
}
