import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Search, MapPin } from "lucide-react";

interface SearchResult {
  id: string;
  name: string;
  type: string;
  floor: number;
}

interface SearchBarProps {
  onSelect?: (result: SearchResult) => void;
}

export default function SearchBar({ onSelect }: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  
  const mockResults: SearchResult[] = [
    { id: "1", name: "Main Entrance", type: "entrance", floor: 1 },
    { id: "2", name: "North Entrance", type: "entrance", floor: 1 },
    { id: "3", name: "South Entrance", type: "entrance", floor: 1 },
    { id: "4", name: "Information Desk", type: "info", floor: 1 },
    { id: "5", name: "Restroom - Floor 1", type: "restroom", floor: 1 },
    { id: "6", name: "Restroom - Floor 2", type: "restroom", floor: 2 },
    { id: "7", name: "Restroom - Floor 3", type: "restroom", floor: 3 },
    { id: "8", name: "Library", type: "facility", floor: 3 },
    { id: "9", name: "Cafeteria", type: "food", floor: 1 },
    { id: "10", name: "Coffee Shop", type: "food", floor: 2 },
    { id: "11", name: "Food Court", type: "food", floor: 1 },
    { id: "12", name: "Lecture Hall A", type: "classroom", floor: 2 },
    { id: "13", name: "Lecture Hall B", type: "classroom", floor: 2 },
    { id: "14", name: "Computer Lab 101", type: "classroom", floor: 1 },
    { id: "15", name: "Computer Lab 201", type: "classroom", floor: 2 },
    { id: "16", name: "Administration Office", type: "office", floor: 3 },
    { id: "17", name: "Student Services", type: "office", floor: 1 },
    { id: "18", name: "Bookstore", type: "shop", floor: 1 },
    { id: "19", name: "ATM", type: "service", floor: 1 },
    { id: "20", name: "Elevator A", type: "elevator", floor: 1 },
    { id: "21", name: "Elevator B", type: "elevator", floor: 1 },
    { id: "22", name: "Emergency Exit - East", type: "exit", floor: 1 },
    { id: "23", name: "Emergency Exit - West", type: "exit", floor: 1 },
    { id: "24", name: "Parking Garage", type: "parking", floor: 0 },
    { id: "25", name: "Auditorium", type: "facility", floor: 2 },
    { id: "26", name: "Conference Room 301", type: "room", floor: 3 },
    { id: "27", name: "Conference Room 302", type: "room", floor: 3 },
    { id: "28", name: "Gymnasium", type: "facility", floor: 1 },
    { id: "29", name: "Medical Center", type: "health", floor: 2 },
    { id: "30", name: "Study Area - Quiet Zone", type: "facility", floor: 3 },
    { id: "31", name: "Vending Machines", type: "service", floor: 2 },
    { id: "32", name: "Printing Center", type: "service", floor: 1 },
    { id: "33", name: "Lost and Found", type: "service", floor: 1 },
    { id: "34", name: "Security Office", type: "office", floor: 1 },
    { id: "35", name: "Career Center", type: "office", floor: 2 },
    { id: "36", name: "Chemistry Lab", type: "classroom", floor: 4 },
    { id: "37", name: "Physics Lab", type: "classroom", floor: 4 },
    { id: "38", name: "Biology Lab", type: "classroom", floor: 3 },
    { id: "39", name: "Art Studio", type: "classroom", floor: 5 },
    { id: "40", name: "Music Room", type: "classroom", floor: 5 },
    { id: "41", name: "Theater", type: "facility", floor: 1 },
    { id: "42", name: "Rooftop Garden", type: "outdoor", floor: 5 },
    { id: "43", name: "Lounge Area", type: "facility", floor: 2 },
    { id: "44", name: "Faculty Lounge", type: "office", floor: 4 },
    { id: "45", name: "Mail Room", type: "service", floor: 1 },
  ];
  
  const filteredResults = query.length > 0
    ? mockResults.filter(r => 
        r.name.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  const handleSelect = (result: SearchResult) => {
    setQuery(result.name);
    setIsOpen(false);
    onSelect?.(result);
    console.log('Selected destination:', result.name);
  };

  return (
    <div className="relative w-full max-w-md" data-testid="search-bar">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search for a destination..."
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          className="pl-10 bg-background/95 backdrop-blur-sm"
          data-testid="input-search"
        />
      </div>
      
      {isOpen && filteredResults.length > 0 && (
        <Card className="absolute top-full mt-2 w-full p-2 max-h-60 overflow-y-auto z-50">
          {filteredResults.map((result) => (
            <button
              key={result.id}
              className="w-full text-left p-2 rounded-md hover-elevate flex items-center gap-2"
              onClick={() => handleSelect(result)}
              data-testid={`result-${result.id}`}
            >
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <div className="flex-1">
                <div className="font-medium text-sm">{result.name}</div>
                <div className="text-xs text-muted-foreground">Floor {result.floor}</div>
              </div>
            </button>
          ))}
        </Card>
      )}
    </div>
  );
}
