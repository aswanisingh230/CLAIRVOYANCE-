import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, ArrowUp, DoorOpen, Navigation } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface RouteStep {
  id: string;
  instruction: string;
  distance: string;
  icon: "straight" | "stairs" | "door" | "turn";
}

interface RoutePanelProps {
  isActive?: boolean;
  from?: string;
  to?: string;
  distance?: string;
  estimatedTime?: string;
  steps?: RouteStep[];
}

const iconMap = {
  straight: ArrowUp,
  stairs: ArrowUp,
  door: DoorOpen,
  turn: ArrowRight,
};

export default function RoutePanel({
  isActive = false,
  from = "Main Entrance",
  to = "Library - Floor 3",
  distance = "250m",
  estimatedTime = "4 min",
  steps = []
}: RoutePanelProps) {
  if (!isActive) {
    return null;
  }

  return (
    <Card className="p-4 bg-background/95 backdrop-blur-sm w-full md:w-80" data-testid="route-panel">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Active Route</h3>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => console.log('Cancel navigation')}
            data-testid="button-cancel-route"
          >
            Cancel
          </Button>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary" />
            <span className="text-sm font-medium">{from}</span>
          </div>
          <div className="ml-1.5 border-l-2 border-dashed border-muted-foreground h-4" />
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full border-2 border-primary" />
            <span className="text-sm font-medium">{to}</span>
          </div>
        </div>
        
        <div className="flex gap-4 text-sm">
          <div>
            <span className="text-muted-foreground">Distance:</span>{" "}
            <span className="font-medium">{distance}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Time:</span>{" "}
            <span className="font-medium">{estimatedTime}</span>
          </div>
        </div>
        
        <Button 
          className="w-full" 
          onClick={() => console.log('Start AR Navigation')}
          data-testid="button-start-ar"
        >
          <Navigation className="mr-2 h-4 w-4" />
          Start AR Navigation
        </Button>
        
        {steps.length > 0 && (
          <div className="border-t pt-4">
            <h4 className="font-medium text-sm mb-3">Turn-by-turn</h4>
            <div className="space-y-3">
              {steps.map((step, index) => {
                const Icon = iconMap[step.icon];
                return (
                  <div 
                    key={step.id} 
                    className="flex items-start gap-3"
                    data-testid={`step-${index}`}
                  >
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm">{step.instruction}</p>
                      <Badge variant="secondary" className="mt-1 text-xs">
                        {step.distance}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
