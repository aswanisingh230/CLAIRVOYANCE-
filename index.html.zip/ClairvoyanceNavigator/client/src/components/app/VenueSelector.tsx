import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Building2, GraduationCap, Plane, Train } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Venue {
  id: string;
  name: string;
  type: string;
  icon: any;
  floors: number;
  size: string;
}

const venues: Venue[] = [
  {
    id: "college",
    name: "Central University",
    type: "College Campus",
    icon: GraduationCap,
    floors: 5,
    size: "50,000 sq ft"
  },
  {
    id: "airport",
    name: "International Airport - Terminal 2",
    type: "Airport",
    icon: Plane,
    floors: 3,
    size: "120,000 sq ft"
  },
  {
    id: "metro",
    name: "Downtown Metro Station",
    type: "Metro Station",
    icon: Train,
    floors: 2,
    size: "30,000 sq ft"
  },
  {
    id: "hospital",
    name: "City Medical Center",
    type: "Hospital",
    icon: Building2,
    floors: 8,
    size: "200,000 sq ft"
  }
];

interface VenueSelectorProps {
  currentVenue?: Venue;
  onSelect?: (venue: Venue) => void;
}

export default function VenueSelector({ 
  currentVenue = venues[0],
  onSelect 
}: VenueSelectorProps) {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(currentVenue);

  const handleSelect = (venue: Venue) => {
    setSelected(venue);
    onSelect?.(venue);
    setOpen(false);
    console.log('Venue selected:', venue.name);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="gap-2"
          data-testid="button-venue-selector"
        >
          <selected.icon className="h-4 w-4" />
          {selected.name}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Select Venue</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {venues.map((venue) => (
            <Card
              key={venue.id}
              className={`p-4 cursor-pointer hover-elevate ${
                selected.id === venue.id ? 'border-primary' : ''
              }`}
              onClick={() => handleSelect(venue)}
              data-testid={`venue-${venue.id}`}
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <venue.icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-1">{venue.name}</h3>
                  <Badge variant="secondary" className="mb-2">
                    {venue.type}
                  </Badge>
                  <div className="flex gap-3 text-xs text-muted-foreground">
                    <span>{venue.floors} floors</span>
                    <span>{venue.size}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
