import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import heroImage from "@assets/generated_images/3D_indoor_navigation_hero_2f29cd64.png";

export default function CTA() {
  return (
    <section className="relative py-20 px-4 overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/80" />
      </div>
      
      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">
          Start Navigating Today
        </h2>
        <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
          Join hundreds of venues already using Clairvoyance to help visitors navigate with confidence.
        </p>
        <Button 
          size="lg" 
          className="bg-primary/90 backdrop-blur-sm hover:bg-primary text-primary-foreground border border-primary-border"
          data-testid="button-get-started"
          onClick={() => console.log('Get Started clicked')}
        >
          Get Started <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </section>
  );
}
