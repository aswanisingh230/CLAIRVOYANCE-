import campusImage from "@assets/generated_images/Student_navigating_campus_70ed3210.png";
import airportImage from "@assets/generated_images/Airport_traveler_navigation_f12a0632.png";
import arImage from "@assets/generated_images/AR_navigation_in_action_cf0c3296.png";
import floorPlanImage from "@assets/generated_images/3D_floor_plan_visualization_a301eff3.png";

const useCases = [
  {
    title: "College Campus Navigation",
    description: "Help students and visitors find classrooms, departments, libraries, and campus facilities with ease. Perfect for orientation and daily navigation.",
    image: campusImage,
    reverse: false
  },
  {
    title: "Airport Wayfinding",
    description: "Guide travelers to gates, baggage claim, check-in counters, and amenities. Reduce stress and ensure on-time arrivals at departure gates.",
    image: airportImage,
    reverse: true
  },
  {
    title: "Metro Station Guidance",
    description: "Navigate complex underground stations with multiple lines, exits, and platforms. Clear directions to ticket machines, platforms, and street exits.",
    image: arImage,
    reverse: false
  },
  {
    title: "Hospital Navigation",
    description: "Direct patients and visitors to departments, rooms, pharmacies, and facilities in large medical complexes. Reduce anxiety during stressful visits.",
    image: floorPlanImage,
    reverse: true
  }
];

export default function UseCases() {
  return (
    <section className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-display text-4xl font-bold mb-4">
            Built for Every Indoor Space
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            From education to transportation, Clairvoyance adapts to any venue
          </p>
        </div>
        
        <div className="space-y-16">
          {useCases.map((useCase, index) => (
            <div 
              key={index}
              className={`flex flex-col ${useCase.reverse ? 'md:flex-row-reverse' : 'md:flex-row'} gap-8 items-center`}
              data-testid={`usecase-${index}`}
            >
              <div className="flex-1">
                <img 
                  src={useCase.image} 
                  alt={useCase.title}
                  className="w-full h-auto rounded-md"
                />
              </div>
              <div className="flex-1 space-y-4">
                <h3 className="font-display text-3xl font-bold">
                  {useCase.title}
                </h3>
                <p className="text-muted-foreground text-lg">
                  {useCase.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
