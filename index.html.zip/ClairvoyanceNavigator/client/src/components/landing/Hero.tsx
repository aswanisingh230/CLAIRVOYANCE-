import { Button } from "@/components/ui/button";
import { ArrowRight, Play } from "lucide-react";
import heroImage from "@assets/generated_images/3D_indoor_navigation_hero_2f29cd64.png";

export default function Hero() {
  return (
    <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/80" />
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="font-display text-5xl md:text-7xl font-bold text-white mb-6">
          Navigate Any Space
          <br />
          With Confidence
        </h1>
        <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-8">
          Your personal digital compass for complex indoor environments. 
          AR-powered navigation for colleges, airports, metro stations, and more.
        </p>
        
        <div className="flex flex-wrap items-center justify-center gap-4">
          <Button 
            size="lg" 
            className="bg-primary/90 backdrop-blur-sm hover:bg-primary text-primary-foreground border border-primary-border"
            data-testid="button-try-demo"
            onClick={() => console.log('Try Demo clicked')}
          >
            Try Demo <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20"
            data-testid="button-watch-video"
            onClick={() => console.log('Watch Video clicked')}
          >
            <Play className="mr-2 h-4 w-4" /> Watch Video
          </Button>
        </div>
        
        <p className="mt-8 text-sm text-white/70">
          Trusted by 100+ venues worldwide
        </p>
      </div>
    </section>
  );
}
