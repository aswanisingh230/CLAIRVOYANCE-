import { Card } from "@/components/ui/card";
import { Search, Route, Navigation } from "lucide-react";

const steps = [
  {
    number: 1,
    icon: Search,
    title: "Select Destination",
    description: "Search for your destination within the venue using our smart autocomplete system."
  },
  {
    number: 2,
    icon: Route,
    title: "View 3D Route",
    description: "Preview your route on an interactive 3D map showing all floors and pathways."
  },
  {
    number: 3,
    icon: Navigation,
    title: "Follow AR Guidance",
    description: "Activate AR mode for real-time navigation arrows overlaid on your camera view."
  }
];

export default function HowItWorks() {
  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-display text-4xl font-bold mb-4">
            How It Works
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Get from point A to point B in three simple steps
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step) => (
            <div key={step.number} className="relative" data-testid={`step-${step.number}`}>
              <Card className="p-6 text-center h-full">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary text-primary-foreground font-bold text-2xl mb-4">
                  {step.number}
                </div>
                <div className="mb-4">
                  <step.icon className="h-8 w-8 mx-auto text-primary" />
                </div>
                <h3 className="font-semibold text-xl mb-2">{step.title}</h3>
                <p className="text-muted-foreground">
                  {step.description}
                </p>
              </Card>
              
              {step.number < 3 && (
                <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                  <div className="w-8 h-0.5 bg-border" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
