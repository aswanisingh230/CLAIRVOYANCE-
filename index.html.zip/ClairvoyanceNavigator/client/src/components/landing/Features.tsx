import { Card } from "@/components/ui/card";
import { Camera, Map, Navigation, MapPin, Building2, Users } from "lucide-react";

const features = [
  {
    icon: Camera,
    title: "AR Navigation",
    description: "Real-time augmented reality guidance overlays directions directly on your camera view for intuitive wayfinding."
  },
  {
    icon: Map,
    title: "3D Mapping",
    description: "Interactive multi-floor maps with detailed 3D visualization help you understand complex indoor layouts instantly."
  },
  {
    icon: Navigation,
    title: "Smart Pathfinding",
    description: "Intelligent routing algorithms calculate the fastest path while considering accessibility needs and preferences."
  },
  {
    icon: MapPin,
    title: "POI Discovery",
    description: "Easily locate restrooms, exits, elevators, information desks, and other amenities throughout any venue."
  },
  {
    icon: Building2,
    title: "Multi-Venue Support",
    description: "Navigate colleges, airports, metro stations, hospitals, and shopping centers all from a single platform."
  },
  {
    icon: Users,
    title: "Accessibility First",
    description: "Wheelchair-friendly routes, elevator prioritization, and inclusive design for all visitors."
  }
];

export default function Features() {
  return (
    <section className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-display text-4xl font-bold mb-4">
            Everything You Need to Navigate
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Powerful features designed to make indoor navigation effortless and accessible for everyone.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="p-6 hover-elevate transition-all"
              data-testid={`card-feature-${index}`}
            >
              <div className="mb-4">
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
              </div>
              <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">
                {feature.description}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
