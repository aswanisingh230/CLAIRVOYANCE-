import CTA from '../landing/CTA'

export default function CTAExample() {
  return <CTA />
}
