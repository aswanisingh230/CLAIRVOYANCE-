import HowItWorks from '../landing/HowItWorks'

export default function HowItWorksExample() {
  return <HowItWorks />
}
