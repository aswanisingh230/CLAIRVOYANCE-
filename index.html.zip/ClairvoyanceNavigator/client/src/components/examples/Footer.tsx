import Footer from '../landing/Footer'

export default function FooterExample() {
  return <Footer />
}
