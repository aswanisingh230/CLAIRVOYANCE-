import RoutePanel from '../app/RoutePanel'

export default function RoutePanelExample() {
  const mockSteps = [
    { id: '1', instruction: 'Head straight for 50m', distance: '50m', icon: 'straight' as const },
    { id: '2', instruction: 'Take stairs to Floor 2', distance: '15m', icon: 'stairs' as const },
    { id: '3', instruction: 'Turn right through the door', distance: '10m', icon: 'door' as const },
    { id: '4', instruction: 'Continue straight', distance: '80m', icon: 'straight' as const }
  ];
  
  return (
    <div className="p-4">
      <RoutePanel 
        isActive={true}
        steps={mockSteps}
      />
    </div>
  )
}
