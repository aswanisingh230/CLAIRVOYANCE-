import MapViewer from '../app/MapViewer'

export default function MapViewerExample() {
  const mockPath = [
    { x: 30, y: 50 },
    { x: 40, y: 50 },
    { x: 40, y: 30 },
    { x: 60, y: 30 }
  ];
  
  const mockMarkers = [
    { id: '1', x: 30, y: 50, type: 'start', label: 'Start' },
    { id: '2', x: 60, y: 30, type: 'end', label: 'End' }
  ];
  
  return (
    <div className="h-screen">
      <MapViewer activePath={mockPath} markers={mockMarkers} />
    </div>
  )
}
