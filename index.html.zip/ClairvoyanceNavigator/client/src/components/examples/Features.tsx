import Features from '../landing/Features'

export default function FeaturesExample() {
  return <Features />
}
