import UseCases from '../landing/UseCases'

export default function UseCasesExample() {
  return <UseCases />
}
