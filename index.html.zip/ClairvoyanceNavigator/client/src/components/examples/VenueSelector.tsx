import VenueSelector from '../app/VenueSelector'

export default function VenueSelectorExample() {
  return (
    <div className="p-4">
      <VenueSelector />
    </div>
  )
}
