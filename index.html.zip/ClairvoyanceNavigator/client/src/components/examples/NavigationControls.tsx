import NavigationControls from '../app/NavigationControls'

export default function NavigationControlsExample() {
  return (
    <div className="p-4">
      <NavigationControls />
    </div>
  )
}
