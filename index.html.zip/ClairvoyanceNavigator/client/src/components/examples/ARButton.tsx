import ARButton from '../app/ARButton'

export default function ARButtonExample() {
  return (
    <div className="p-4">
      <ARButton />
    </div>
  )
}
