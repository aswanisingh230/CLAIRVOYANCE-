import { useState } from "react";
import MapViewer from "@/components/app/MapViewer";
import SearchBar from "@/components/app/SearchBar";
import NavigationControls from "@/components/app/NavigationControls";
import RoutePanel from "@/components/app/RoutePanel";
import VenueSelector from "@/components/app/VenueSelector";
import ARButton from "@/components/app/ARButton";
import ThemeToggle from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { Navigation, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function NavigationApp() {
  const [currentFloor, setCurrentFloor] = useState(1);
  const [activeRoute, setActiveRoute] = useState(false);
  
  const mockPath = activeRoute ? [
    { x: 30, y: 50 },
    { x: 40, y: 50 },
    { x: 40, y: 30 },
    { x: 60, y: 30 }
  ] : [];
  
  const mockMarkers = activeRoute ? [
    { id: '1', x: 30, y: 50, type: 'start', label: 'Start' },
    { id: '2', x: 60, y: 30, type: 'end', label: 'End' }
  ] : [];
  
  const mockSteps = [
    { id: '1', instruction: 'Head straight for 50m', distance: '50m', icon: 'straight' as const },
    { id: '2', instruction: 'Take stairs to Floor 2', distance: '15m', icon: 'stairs' as const },
    { id: '3', instruction: 'Turn right through the door', distance: '10m', icon: 'door' as const },
    { id: '4', instruction: 'Continue straight to Library', distance: '80m', icon: 'straight' as const }
  ];

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <header className="border-b bg-background p-4 flex items-center justify-between gap-4 flex-shrink-0">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button 
              variant="ghost" 
              size="icon"
              data-testid="button-back-home"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          
          <div className="flex items-center gap-2">
            <Navigation className="h-5 w-5 text-primary" />
            <span className="font-display font-bold text-lg hidden sm:inline">Clairvoyance</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <VenueSelector />
          <ThemeToggle />
        </div>
      </header>
      
      <div className="flex-1 relative overflow-hidden">
        <MapViewer activePath={mockPath} markers={mockMarkers} />
        
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 w-full max-w-md px-4">
          <SearchBar 
            onSelect={(result) => {
              console.log('Destination selected:', result);
              setActiveRoute(true);
            }}
          />
        </div>
        
        <div className="absolute left-4 bottom-4 z-20 hidden md:block">
          <NavigationControls 
            currentFloor={currentFloor}
            onFloorChange={setCurrentFloor}
          />
        </div>
        
        <div className="absolute right-4 bottom-4 z-20 md:hidden">
          <ARButton />
        </div>
        
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 w-full max-w-md px-4 md:left-auto md:right-4 md:translate-x-0 md:bottom-4">
          <RoutePanel 
            isActive={activeRoute}
            steps={mockSteps}
          />
        </div>
        
        <div className="absolute right-4 bottom-4 z-20 hidden md:block">
          <ARButton />
        </div>
      </div>
    </div>
  );
}
