# Clairvoyance Design Guidelines

## Design Approach

**Hybrid Approach**: Drawing inspiration from navigation leaders (Google Maps, Apple Maps, Citymapper) with emphasis on clarity, spatial awareness, and minimal interface distraction. The design prioritizes functionality while maintaining a modern, tech-forward aesthetic that builds trust in an innovative AR navigation system.

**Core Principles**:
- Interface recedes, content (map/AR view) dominates
- Instant clarity over visual decoration
- Spatial hierarchy through layering and elevation
- Confident, accessible wayfinding

---

## Typography System

**Font Stack**: 
- Primary: Inter (via Google Fonts) - for UI, controls, labels
- Display: Space Grotesk (via Google Fonts) - for marketing headlines, feature titles

**Type Scale**:
- Hero Display: text-6xl to text-7xl, font-bold (Space Grotesk)
- Section Headers: text-4xl, font-bold (Space Grotesk)
- Navigation Instructions: text-2xl to text-3xl, font-semibold (Inter)
- Body Text: text-base to text-lg, font-normal (Inter)
- UI Labels: text-sm, font-medium (Inter)
- Captions/Metadata: text-xs, font-normal (Inter)

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, and 12 for consistency
- Micro spacing (buttons, inputs): p-2, gap-2
- Component spacing: p-4, gap-4, m-4
- Section padding: p-6 to p-8
- Major sections: py-12 to py-20

**Grid Strategy**:
- App Interface: Full viewport with overlaid controls (floating panels)
- Marketing: Standard container max-w-7xl with responsive grids
- Feature showcases: grid-cols-1 md:grid-cols-2 lg:grid-cols-3

---

## Component Library

### Marketing/Landing Page Components

**Hero Section** (80vh):
- Large hero image showing 3D indoor map visualization or AR navigation in action
- Centered headline with primary CTA
- Blurred background buttons for "Try Demo" and "Learn More"
- Trust indicator: "Trusted by 100+ venues worldwide"

**Feature Grid** (3-column desktop, 1-column mobile):
- Icon + headline + description cards
- Icons from Heroicons (outline style)
- Features: AR Navigation, 3D Mapping, Smart Pathfinding, POI Discovery, Multi-Venue Support, Accessibility First
- Each card with subtle border and generous padding (p-6)

**How It Works** (Step-by-step visual):
- 3-column layout with numbered steps
- Screenshots/illustrations of: 1) Select destination, 2) View 3D route, 3) Follow AR guidance
- Connected with visual flow indicators

**Use Cases** (2-column alternating layout):
- Large image + text pairs
- Showcasing: College Campus Navigation, Airport Wayfinding, Metro Station Guidance, Hospital Navigation
- Asymmetric layout for visual interest

**CTA Section**:
- Full-width with background image (blurred)
- Centered headline + supporting text + primary button
- "Start Navigating Today" with demo signup

**Footer**:
- Multi-column (4 sections): Product, Company, Resources, Connect
- Newsletter signup
- Social links
- Trust badges for partnerships/certifications

### Application Interface Components

**Map Viewer** (Primary Canvas):
- Full viewport 3D canvas
- Minimal chrome - content is king
- Floating control panels with backdrop blur

**Navigation Control Panel** (Floating):
- Semi-transparent background with backdrop-blur
- Rounded corners (rounded-2xl)
- Shadow elevation for depth
- Position: bottom-left or bottom-center
- Includes: zoom controls, floor selector, rotate/tilt controls

**Search Bar** (Floating Top):
- Full-width on mobile, max-w-md on desktop
- Autocomplete dropdown with venue context
- Icon: search (Heroicons)
- Position: top-center with gap-4 from edge

**Route Information Panel** (Expandable):
- Slides up from bottom on mobile, sidebar on desktop
- Shows: distance, estimated time, turn-by-turn instructions
- Expandable/collapsible with smooth transitions
- Step indicators with icons (stairs, elevator, door, etc.)

**POI Markers** (On Map):
- Category-based icons (Heroicons): restroom, information, food, exit, elevator, stairs
- Consistent size and style
- Tap/click for details popup

**Venue Selector**:
- Dropdown or modal with venue cards
- Each venue: thumbnail image + name + type + quick stats
- Grid layout in modal view

**AR View Toggle** (Floating Button):
- Prominent circular button
- Icon: camera or AR symbol
- Position: bottom-right
- Pulsing subtle animation when AR available

---

## Navigation & Interaction Patterns

**Multi-Level Navigation**:
- Top bar: Venue selector, settings, help
- Map controls: Floating panels, non-intrusive
- Bottom navigation (mobile): Home, Search, Saved, Profile

**Progressive Disclosure**:
- Start with overview map
- Tap destination → route preview
- "Start Navigation" → detailed turn-by-turn
- AR mode as optional enhancement

**Gestures**:
- Map: Pinch to zoom, drag to pan, two-finger rotate
- Clear visual feedback for all interactions
- Smooth 60fps animations

---

## Images

**Large Hero Image**: Yes - full-width, 80vh
- Description: Futuristic 3D indoor map visualization showing a college campus or airport terminal with glowing pathways, AR waypoints, and clean modern interface overlays. Tech-forward, blue/cyan accents suggesting digital navigation.

**Feature Section Images** (6 images):
- AR navigation in action (person using phone with AR overlay)
- 3D floor plan visualization (isometric view)
- POI markers on map interface
- Multi-floor navigation view
- Real-time positioning accuracy demo
- Accessibility features showcase

**Use Case Images** (4 images):
- College student navigating campus with phone
- Traveler at airport terminal using AR guidance
- Commuter in metro station
- Visitor in hospital complex

**Screenshots** (Throughout):
- Actual app interface showing map viewer
- Search functionality with autocomplete
- Route planning interface
- AR view mode

---

## Accessibility & Usability

**High Contrast UI**:
- Clear text hierarchy with strong contrast ratios
- Map controls always readable against any map view
- Use backdrop-blur and semi-transparent backgrounds for floating panels

**Touch Targets**:
- Minimum 44x44px for all interactive elements
- Generous spacing between map controls

**Focus States**:
- Clear focus indicators for keyboard navigation
- Logical tab order through interface elements

**Screen Reader Support**:
- Descriptive labels for all navigation controls
- Announce route updates and turn-by-turn instructions

---

## Design System Foundation

This application uses **custom design patterns** inspired by navigation industry leaders, prioritizing:
- **Spatial clarity**: Map/AR view is always the focus
- **Layered information**: Progressive disclosure through floating panels
- **Confident wayfinding**: Large, clear navigation instructions
- **Professional trust**: Clean, minimal aesthetic that doesn't distract

The interface should feel like a trusted guide - modern, capable, and absolutely clear about where you are and where you're going.